Mastering the tidyverse
========================================================
author: Lisa Bramer
date: June 27, 2019
autosize: true

<style>
.small-code pre code {
  font-size: 1em;
}
</style>

tidyverse
========================================================

Compilation of 6 core packages: 
- *readr*
- *tibble*
- ggplot2
- **dplyr**
- *tidyr*
- **purrr**

Access and Resources
========================================================


```r
install.packages("tidyverse")
```

```r
library(tidyverse)
```

The basics: https://www.tidyverse.org

H. Wickham's book: http://r4ds.had.co.nz

Cheat Sheets: https://www.rstudio.com/resources/cheatsheets/

General Work Flow
========================================================

![](tidyverse1.png)

readr
========================================================
Ingest data into R:
- read_csv(): comma separated (CSV) files
- read_tsv(): tab separated files
- read_delim(): general delimited files
- read_fwf(): fixed width files
- read_table(): tabular files where colums are separated by white-space.
- read_log(): web log files

Output: tibble, data.frame

readr
====================================================
- Generally faster than base R functions ('read.csv', etc)
- Strings are left as is by default
- Some automatic parsing of common date/time formats.


```r
gapminder <- read_csv("gapminder.csv")

# same dataset available from library(gapminder) #
```

tibble
=======================================================
- tibble (tbl_df) is a data.frame 
- they don’t change variable names or types
- don’t do partial matching
- entries can be single values or more complex objects (e.g. list, data.frame, etc.)

tibble
===========================================================
class: small-code

```r
gapminder
```

```
# A tibble: 1,704 x 6
   country     continent  year lifeExp      pop gdpPercap
   <chr>       <chr>     <dbl>   <dbl>    <dbl>     <dbl>
 1 Afghanistan Asia       1952    28.8  8425333      779.
 2 Afghanistan Asia       1957    30.3  9240934      821.
 3 Afghanistan Asia       1962    32.0 10267083      853.
 4 Afghanistan Asia       1967    34.0 11537966      836.
 5 Afghanistan Asia       1972    36.1 13079460      740.
 6 Afghanistan Asia       1977    38.4 14880372      786.
 7 Afghanistan Asia       1982    39.9 12881816      978.
 8 Afghanistan Asia       1987    40.8 13867957      852.
 9 Afghanistan Asia       1992    41.7 16317921      649.
10 Afghanistan Asia       1997    41.8 22227415      635.
# … with 1,694 more rows
```

tibble
==========================================================
class: small-code

```r
glimpse(gapminder)
```

```
Observations: 1,704
Variables: 6
$ country   <chr> "Afghanistan", "Afghanistan", "Afghanistan", "Afghanis…
$ continent <chr> "Asia", "Asia", "Asia", "Asia", "Asia", "Asia", "Asia"…
$ year      <dbl> 1952, 1957, 1962, 1967, 1972, 1977, 1982, 1987, 1992, …
$ lifeExp   <dbl> 28.801, 30.332, 31.997, 34.020, 36.088, 38.438, 39.854…
$ pop       <dbl> 8425333, 9240934, 10267083, 11537966, 13079460, 148803…
$ gdpPercap <dbl> 779.4453, 820.8530, 853.1007, 836.1971, 739.9811, 786.…
```

tibble
===========================================================
class: small-code

```r
iris_tbl <- as_tibble(iris)
```

tibble
==============================================================
class: small-code

```r
tibble(x = 1:5, y = rnorm(5), z = x + y)
```

```
# A tibble: 5 x 3
      x      y      z
  <int>  <dbl>  <dbl>
1     1 -1.66  -0.657
2     2  1.64   3.64 
3     3 -0.712  2.29 
4     4 -0.210  3.79 
5     5 -0.393  4.61 
```

tidyr
=============================================================
class: small-code

Manipulate data structure and shape

gather(): 
- turns wide data into long data
- equivalent to 'melt' in reshape2

spread():
- turns long data in wide data
- equivalent to 'cast' in reshape2

dplyr - filter()
================================================
class: small-code

- choose rows to keep
- equivalent to 'subset()'

```r
gapminder %>% filter(country == "Ireland")
```

```
# A tibble: 12 x 6
   country continent  year lifeExp     pop gdpPercap
   <chr>   <chr>     <dbl>   <dbl>   <dbl>     <dbl>
 1 Ireland Europe     1952    66.9 2952156     5210.
 2 Ireland Europe     1957    68.9 2878220     5599.
 3 Ireland Europe     1962    70.3 2830000     6632.
 4 Ireland Europe     1967    71.1 2900100     7656.
 5 Ireland Europe     1972    71.3 3024400     9531.
 6 Ireland Europe     1977    72.0 3271900    11151.
 7 Ireland Europe     1982    73.1 3480000    12618.
 8 Ireland Europe     1987    74.4 3539900    13873.
 9 Ireland Europe     1992    75.5 3557761    17559.
10 Ireland Europe     1997    76.1 3667233    24522.
11 Ireland Europe     2002    77.8 3879155    34077.
12 Ireland Europe     2007    78.9 4109086    40676.
```

dplyr - select()
================================================
class: small-code

- choose columns to keep

```r
gapminder %>% select(country, continent)
```

```
# A tibble: 1,704 x 2
   country     continent
   <chr>       <chr>    
 1 Afghanistan Asia     
 2 Afghanistan Asia     
 3 Afghanistan Asia     
 4 Afghanistan Asia     
 5 Afghanistan Asia     
 6 Afghanistan Asia     
 7 Afghanistan Asia     
 8 Afghanistan Asia     
 9 Afghanistan Asia     
10 Afghanistan Asia     
# … with 1,694 more rows
```

```r
# gapminder[,c("country", "continent")] #
```

dplyr - arrange()
================================================
class: small-code

- order rows by variable

```r
gapminder %>% arrange(desc(pop))
```

```
# A tibble: 1,704 x 6
   country continent  year lifeExp        pop gdpPercap
   <chr>   <chr>     <dbl>   <dbl>      <dbl>     <dbl>
 1 China   Asia       2007    73.0 1318683096     4959.
 2 China   Asia       2002    72.0 1280400000     3119.
 3 China   Asia       1997    70.4 1230075000     2289.
 4 China   Asia       1992    68.7 1164970000     1656.
 5 India   Asia       2007    64.7 1110396331     2452.
 6 China   Asia       1987    67.3 1084035000     1379.
 7 India   Asia       2002    62.9 1034172547     1747.
 8 China   Asia       1982    65.5 1000281000      962.
 9 India   Asia       1997    61.8  959000000     1459.
10 China   Asia       1977    64.0  943455000      741.
# … with 1,694 more rows
```

```r
# gapminder[order(gapminder$pop, decreasing = T),] #
```

dplyr - summarise()
================================================
class: small-code

- calculate **single value** summaries from multiple values

```r
gapminder %>% summarise(median(pop))
```

```
# A tibble: 1 x 1
  `median(pop)`
          <dbl>
1      7023596.
```

```r
# median(gapminder$pop) #
```

dplyr - mutate()
================================================
class: small-code

- create additional columns based on data

```r
# gapminder$pop_thousand <- gapminder$pop/1000 #
gapminder %>% mutate(pop_thousand = pop/1000)
```

```
# A tibble: 1,704 x 7
   country     continent  year lifeExp      pop gdpPercap pop_thousand
   <chr>       <chr>     <dbl>   <dbl>    <dbl>     <dbl>        <dbl>
 1 Afghanistan Asia       1952    28.8  8425333      779.        8425.
 2 Afghanistan Asia       1957    30.3  9240934      821.        9241.
 3 Afghanistan Asia       1962    32.0 10267083      853.       10267.
 4 Afghanistan Asia       1967    34.0 11537966      836.       11538.
 5 Afghanistan Asia       1972    36.1 13079460      740.       13079.
 6 Afghanistan Asia       1977    38.4 14880372      786.       14880.
 7 Afghanistan Asia       1982    39.9 12881816      978.       12882.
 8 Afghanistan Asia       1987    40.8 13867957      852.       13868.
 9 Afghanistan Asia       1992    41.7 16317921      649.       16318.
10 Afghanistan Asia       1997    41.8 22227415      635.       22227.
# … with 1,694 more rows
```

dplyr - group_by()
=================================================
class: small-code

Divide data into smaller subsets

```r
# equivalent to #
# group_by(gapminder, country) #
gapminder %>% group_by(country)
```

```
# A tibble: 1,704 x 6
# Groups:   country [142]
   country     continent  year lifeExp      pop gdpPercap
   <chr>       <chr>     <dbl>   <dbl>    <dbl>     <dbl>
 1 Afghanistan Asia       1952    28.8  8425333      779.
 2 Afghanistan Asia       1957    30.3  9240934      821.
 3 Afghanistan Asia       1962    32.0 10267083      853.
 4 Afghanistan Asia       1967    34.0 11537966      836.
 5 Afghanistan Asia       1972    36.1 13079460      740.
 6 Afghanistan Asia       1977    38.4 14880372      786.
 7 Afghanistan Asia       1982    39.9 12881816      978.
 8 Afghanistan Asia       1987    40.8 13867957      852.
 9 Afghanistan Asia       1992    41.7 16317921      649.
10 Afghanistan Asia       1997    41.8 22227415      635.
# … with 1,694 more rows
```

dplyr - linking functions
===================================================
class: small-code

Calculate mean population by country

```r
 res <- list()
 cntrys <- unique(gapminder$country)
 for(i in 1:length(cntrys)){
   temp <- subset(gapminder, country == cntrys[i])
   res[[i]] = data.frame(country = cntrys[i], mean_pop = mean(temp$pop))
 }
 head(do.call(rbind, res))
```

```
      country mean_pop
1 Afghanistan 15823715
2     Albania  2580249
3     Algeria 19875406
4      Angola  7309390
5   Argentina 28602240
6   Australia 14649312
```

dplyr - linking functions
===================================================
class: small-code


```r
gapminder %>% group_by(country) %>% summarise(mean_pop = mean(pop))
```

```
# A tibble: 142 x 2
   country      mean_pop
   <chr>           <dbl>
 1 Afghanistan 15823715.
 2 Albania      2580249.
 3 Algeria     19875406.
 4 Angola       7309390.
 5 Argentina   28602240.
 6 Australia   14649312.
 7 Austria      7583298.
 8 Bahrain       373913.
 9 Bangladesh  90755395.
10 Belgium      9725119.
# … with 132 more rows
```

tidyr - nest()
====================================================
class: small-code


```r
byCountry <- by_country <- gapminder %>%
  group_by(country) %>%
  nest()

byCountry
```

```
# A tibble: 142 x 2
   country     data             
   <chr>       <list>           
 1 Afghanistan <tibble [12 × 5]>
 2 Albania     <tibble [12 × 5]>
 3 Algeria     <tibble [12 × 5]>
 4 Angola      <tibble [12 × 5]>
 5 Argentina   <tibble [12 × 5]>
 6 Australia   <tibble [12 × 5]>
 7 Austria     <tibble [12 × 5]>
 8 Bahrain     <tibble [12 × 5]>
 9 Bangladesh  <tibble [12 × 5]>
10 Belgium     <tibble [12 × 5]>
# … with 132 more rows
```

tidyr - nest()
====================================================
class: small-code


```r
byCountry$data[[1]]
```

```
# A tibble: 12 x 5
   continent  year lifeExp      pop gdpPercap
   <chr>     <dbl>   <dbl>    <dbl>     <dbl>
 1 Asia       1952    28.8  8425333      779.
 2 Asia       1957    30.3  9240934      821.
 3 Asia       1962    32.0 10267083      853.
 4 Asia       1967    34.0 11537966      836.
 5 Asia       1972    36.1 13079460      740.
 6 Asia       1977    38.4 14880372      786.
 7 Asia       1982    39.9 12881816      978.
 8 Asia       1987    40.8 13867957      852.
 9 Asia       1992    41.7 16317921      649.
10 Asia       1997    41.8 22227415      635.
11 Asia       2002    42.1 25268405      727.
12 Asia       2007    43.8 31889923      975.
```

tidyr - unnest()
====================================================
class: small-code


```r
unnest(byCountry)
```

```
# A tibble: 1,704 x 6
   country     continent  year lifeExp      pop gdpPercap
   <chr>       <chr>     <dbl>   <dbl>    <dbl>     <dbl>
 1 Afghanistan Asia       1952    28.8  8425333      779.
 2 Afghanistan Asia       1957    30.3  9240934      821.
 3 Afghanistan Asia       1962    32.0 10267083      853.
 4 Afghanistan Asia       1967    34.0 11537966      836.
 5 Afghanistan Asia       1972    36.1 13079460      740.
 6 Afghanistan Asia       1977    38.4 14880372      786.
 7 Afghanistan Asia       1982    39.9 12881816      978.
 8 Afghanistan Asia       1987    40.8 13867957      852.
 9 Afghanistan Asia       1992    41.7 16317921      649.
10 Afghanistan Asia       1997    41.8 22227415      635.
# … with 1,694 more rows
```

purrr - map()
====================================================
class: small-code


```r
country_model <- function(df){
  lm(lifeExp ~ year, data = df)
}

byCountry %>% mutate(
    model = map(data, country_model),
    resid_mad = map_dbl(model, function(x) mad(resid(x))),
    rsquared = map_dbl(model, function(x) summary(x)$r.squared))
```

```
# A tibble: 142 x 5
   country     data              model  resid_mad rsquared
   <chr>       <list>            <list>     <dbl>    <dbl>
 1 Afghanistan <tibble [12 × 5]> <lm>       1.41     0.948
 2 Albania     <tibble [12 × 5]> <lm>       2.22     0.911
 3 Algeria     <tibble [12 × 5]> <lm>       0.793    0.985
 4 Angola      <tibble [12 × 5]> <lm>       1.49     0.888
 5 Argentina   <tibble [12 × 5]> <lm>       0.238    0.996
 6 Australia   <tibble [12 × 5]> <lm>       0.793    0.980
 7 Austria     <tibble [12 × 5]> <lm>       0.393    0.992
 8 Bahrain     <tibble [12 × 5]> <lm>       1.82     0.967
 9 Bangladesh  <tibble [12 × 5]> <lm>       1.19     0.989
10 Belgium     <tibble [12 × 5]> <lm>       0.235    0.995
# … with 132 more rows
```

Extensions
============================================
- sparklyr for parallelization (not yet supported)
- trelliscopejs
